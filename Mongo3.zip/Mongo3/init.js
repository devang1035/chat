const mongoose = require("mongoose");
const Chat= require("./models/chat.js");

main()
.then(()=>{
    console.log("connection sucessfull");
})
.catch((err) => console.log(err));

async function main() {
  await mongoose.connect("mongodb://127.0.0.1:27017/whatsapp");
}

let allchats= [
    {
    from:"neha",
    to:"priya",
    msg:"send me sheet",
    created_at:new Date(),
    },
    {
        from:"rutu",
        to:"devang",
        msg:"hello",
        created_at:new Date(),
        },
        {
            from:"arya",
            to:"auyshi",
            msg:"hyy",
            created_at:new Date(),
            },
            {
                from:"kena",
                to:"shreyansh",
                msg:"hyy seenu",
                created_at:new Date(),
                },
                {
                    from:"ayushi",
                    to:"param",
                    msg:"hello",
                    created_at:new Date(),
                    },
                  
];

Chat.insertMany(allchats);